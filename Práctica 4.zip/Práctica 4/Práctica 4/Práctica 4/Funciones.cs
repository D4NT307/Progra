﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Práctica_4
{
    class Funciones
    {
        public static double Suma(double n1, double n2, double n3, double n4)
        {
            return n1 + n2 + n3 + n4;
        }
        public static int Buscar(int numB, ListBox lista)
        {
            int cant = 0;
            foreach (int numero in lista.Items)
            {
                if (numero == numB) cant++;
            }
            return cant;
        }
        public static int Fibonacci(int numaF)
        {
            if (numaF <= 1)
            {
                return 1;
            }
            else
            {
                return Fibonacci(numaF - 1) + Fibonacci(numaF - 2);
            }
        }
        public static string Mayor(int n1, int n2)
        {
            if (n1 > n2)
            {
                return "El número 1 (" + n1 + ") es el número mayor.";
            }
            else
            {
                return "El número 2 (" + n2 + ") es el número mayor.";
            }
        }
        public static string Mayor(int n1, int n2, int n3)
        {
            if ((n1 > n2) && (n1 > n3))
            {
                return "El número 1 (" + n1 + ") es el número mayor.";
            }
            else if ((n2 > n1) && (n2 > n3))
            {
                return "El número 2 (" + n2 + ") es el número mayor.";
            }
            else
            {
                return "El número 3 (" + n3 + ") es el número mayor.";
            }
        }
    }
}
