﻿namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstDado = new System.Windows.Forms.ListBox();
            this.btLanzar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstDado
            // 
            this.lstDado.FormattingEnabled = true;
            this.lstDado.Location = new System.Drawing.Point(13, 13);
            this.lstDado.Name = "lstDado";
            this.lstDado.Size = new System.Drawing.Size(120, 251);
            this.lstDado.TabIndex = 0;
            // 
            // btLanzar
            // 
            this.btLanzar.Location = new System.Drawing.Point(36, 271);
            this.btLanzar.Name = "btLanzar";
            this.btLanzar.Size = new System.Drawing.Size(75, 23);
            this.btLanzar.TabIndex = 1;
            this.btLanzar.Text = "Lanzar";
            this.btLanzar.UseVisualStyleBackColor = true;
            this.btLanzar.Click += new System.EventHandler(this.btLanzar_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(150, 305);
            this.Controls.Add(this.btLanzar);
            this.Controls.Add(this.lstDado);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstDado;
        private System.Windows.Forms.Button btLanzar;
    }
}