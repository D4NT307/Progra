﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstAlfabeto = new System.Windows.Forms.ListBox();
            this.btMostrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstAlfabeto
            // 
            this.lstAlfabeto.FormattingEnabled = true;
            this.lstAlfabeto.Location = new System.Drawing.Point(12, 12);
            this.lstAlfabeto.Name = "lstAlfabeto";
            this.lstAlfabeto.Size = new System.Drawing.Size(111, 199);
            this.lstAlfabeto.TabIndex = 0;
            // 
            // btMostrar
            // 
            this.btMostrar.Location = new System.Drawing.Point(30, 227);
            this.btMostrar.Name = "btMostrar";
            this.btMostrar.Size = new System.Drawing.Size(75, 23);
            this.btMostrar.TabIndex = 1;
            this.btMostrar.Text = "Mostrar";
            this.btMostrar.UseVisualStyleBackColor = true;
            this.btMostrar.Click += new System.EventHandler(this.btMostrar_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(133, 260);
            this.Controls.Add(this.btMostrar);
            this.Controls.Add(this.lstAlfabeto);
            this.Name = "Form2";
            this.Text = "Abecedario";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstAlfabeto;
        private System.Windows.Forms.Button btMostrar;
    }
}